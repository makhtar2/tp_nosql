use boutique;

// --- INITIALISATION DU JEU DE DONNÉES (MOCK DATA) ---
db.clients.drop();
db.clients.insertMany([
  { _id: ObjectId("60c72b2f9b1d8b2bad871101"), nom: "Martin", ville: "Lyon", segment: "premium", email: "martin@email.fr" },
  { _id: ObjectId("60c72b2f9b1d8b2bad871102"), nom: "Bernard", ville: "Paris", segment: "standard", email: "bernard@email.fr" },
  { _id: ObjectId("60c72b2f9b1d8b2bad871103"), nom: "Thomas", ville: "Marseille", segment: "premium", email: "thomas@email.fr" },
  { _id: ObjectId("60c72b2f9b1d8b2bad871104"), nom: "Petit", ville: "Lyon", segment: "standard", email: "petit@email.fr" },
  { _id: ObjectId("60c72b2f9b1d8b2bad871105"), nom: "Durand", ville: "Paris", segment: "premium", email: "durand@email.fr" }
]);

db.commandes.drop();
db.commandes.insertMany([
  {
    _id: ObjectId("60c72b2f9b1d8b2bad872201"),
    client_id: ObjectId("60c72b2f9b1d8b2bad871101"),
    date: ISODate("2026-01-10T10:00:00Z"),
    lignes: [
      { sku: "PRD-001", qte: 2, prix_unitaire: 79.99 },
      { sku: "PRD-002", qte: 1, prix_unitaire: 59.99 }
    ],
    statut: "livree",
    montant_total: 219.97
  },
  {
    _id: ObjectId("60c72b2f9b1d8b2bad872202"),
    client_id: ObjectId("60c72b2f9b1d8b2bad871102"),
    date: ISODate("2026-01-15T14:30:00Z"),
    lignes: [
      { sku: "PRD-004", qte: 1, prix_unitaire: 45.00 }
    ],
    statut: "livree",
    montant_total: 45.00
  },
  {
    _id: ObjectId("60c72b2f9b1d8b2bad872203"),
    client_id: ObjectId("60c72b2f9b1d8b2bad871101"),
    date: ISODate("2026-02-05T09:15:00Z"),
    lignes: [
      { sku: "PRD-005", qte: 5, prix_unitaire: 15.00 }
    ],
    statut: "livree",
    montant_total: 75.00
  },
  {
    _id: ObjectId("60c72b2f9b1d8b2bad872204"),
    client_id: ObjectId("60c72b2f9b1d8b2bad871103"),
    date: ISODate("2026-02-12T18:00:00Z"),
    lignes: [
      { sku: "PRD-001", qte: 1, prix_unitaire: 79.99 },
      { sku: "PRD-003", qte: 1, prix_unitaire: 149.99 }
    ],
    statut: "livree",
    montant_total: 229.98
  },
  {
    _id: ObjectId("60c72b2f9b1d8b2bad872205"),
    client_id: ObjectId("60c72b2f9b1d8b2bad871104"),
    date: ISODate("2026-03-01T11:00:00Z"),
    lignes: [
      { sku: "PRD-002", qte: 2, prix_unitaire: 59.99 }
    ],
    statut: "en_cours",
    montant_total: 119.98
  },
  {
    _id: ObjectId("60c72b2f9b1d8b2bad872206"),
    client_id: ObjectId("60c72b2f9b1d8b2bad871105"),
    date: ISODate("2026-03-22T15:45:00Z"),
    lignes: [
      { sku: "PRD-001", qte: 3, prix_unitaire: 79.99 }
    ],
    statut: "livree",
    montant_total: 239.97
  }
]);

// PARTIE 1 — PIPELINES D'AGRÉGATION

db.commandes.aggregate([
  { $match: { statut: "livree" } },
  { $group: { _id: null, totalCA: { $sum: "$montant_total" } } }
]);

db.commandes.aggregate([
  { $match: { statut: "livree" } },
  { $lookup: { from: "clients", localField: "client_id", foreignField: "_id", as: "info" } },
  { $unwind: "$info" },
  { $group: { _id: "$info.segment", ca: { $sum: "$montant_total" } } }
]);

db.commandes.aggregate([
  { $match: { statut: "livree" } },
  { $group: { _id: "$client_id", total: { $sum: "$montant_total" } } },
  { $sort: { total: -1 } },
  { $limit: 3 }
]);

db.commandes.aggregate([
  { $group: { _id: { annee: { $year: "$date" }, mois: { $month: "$date" } }, nb: { $sum: 1 } } },
  { $sort: { "_id.annee": 1, "_id.mois": 1 } }
]);

db.commandes.aggregate([
  { $lookup: { from: "clients", localField: "client_id", foreignField: "_id", as: "info" } },
  { $unwind: "$info" },
  { $group: { _id: "$info.ville", panier: { $avg: "$montant_total" } } }
]);

db.commandes.aggregate([
  { $unwind: "$lignes" },
  { $group: { _id: "$lignes.sku", qte_totale: { $sum: "$lignes.qte" } } },
  { $sort: { qte_totale: -1 } }
]);

// PARTIE 2 — INDEX ET EXPLAIN()

db.commandes.find({ statut: "livree" }).explain("executionStats");

db.commandes.createIndex({ statut: 1, date: -1 });

db.commandes.find({ statut: "livree" }).explain("executionStats");

db.clients.createIndex({ email: 1 }, { unique: true });

// PARTIE 3 — DÉFI

db.clients.aggregate([
  { $lookup: { from: "commandes", localField: "_id", foreignField: "client_id", as: "cmds" } },
  { $project: {
    segment: 1,
    nbCmds: { $size: "$cmds" },
    ca: { $reduce: { input: "$cmds", initialValue: 0, in: { $add: ["$$value", "$$this.montant_total"] } } }
  }},
  { $group: {
    _id: "$segment",
    nbClients: { $sum: 1 },
    caTotal: { $sum: "$ca" },
    moyenneCmds: { $avg: "$nbCmds" }
  }}
]);
